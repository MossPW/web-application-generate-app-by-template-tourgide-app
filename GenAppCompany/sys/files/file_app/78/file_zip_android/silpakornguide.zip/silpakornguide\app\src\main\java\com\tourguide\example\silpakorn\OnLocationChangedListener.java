package com.tourguide.example.silpakorn;

import android.location.Location;


public interface OnLocationChangedListener {
    void onLocationChanged(Location currentLocation);
}
