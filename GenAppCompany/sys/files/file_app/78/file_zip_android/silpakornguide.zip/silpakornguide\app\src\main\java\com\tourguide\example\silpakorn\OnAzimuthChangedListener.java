package com.tourguide.example.silpakorn;


public interface OnAzimuthChangedListener {
    void onAzimuthChanged(float azimuthFrom, float azimuthTo);
}
