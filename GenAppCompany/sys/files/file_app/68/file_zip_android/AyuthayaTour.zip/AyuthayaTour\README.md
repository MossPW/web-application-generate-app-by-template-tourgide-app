# Android Implementation of Augmented Reality

This is a simple example how to implement Augmented Reality on Android device. 

![App screenshot](http://s9.postimg.org/9vl9ra3zz/Screen_Shot_2015_11_04_at_15_04_24.png)

You can see this project running on a video: https://www.youtube.com/watch?v=zFb1NTGYhoU
Example was tested on Nexus 4 and Samsung Galaxy S4. There is possibility that on different devices sensors needs to be implemented in different way.

Whole tutorial about Augmented Reality on Android you can find here: https://netguru.co/blog/augmented-reality-mobile-android
