package com.tourguide.example.silpakorn;
		                   import java.util.ArrayList;

                    public class SetLocation {
                       private ArrayList<AugmentedPOI> mPoiList = new ArrayList<>();
                       private ArrayList<MainPOI> mMainPoiList = new ArrayList<>();

                       SetLocation() {

                       //set mainpoi//
                       MainPOI mMainPOI11 = new MainPOI(11,"กรุงศรีอยุธยา",14.3566312,100.58301080000001);
                                 mMainPoiList.add(mMainPOI11);
                                 
                       ////

                      //set question//
                      SetQuestion question_poi97 = new SetQuestion();
                  QuestionLibrary q56_poi97 = new QuestionLibrary(2,"วัดไชยเป็นวัดไหม",new String[] {"วัด","โบสถ์"},new String[] {"วัด"});
                           question_poi97.addQuestion(q56_poi97);
                          SetQuestion question_poi99 = new SetQuestion();
                  QuestionLibrary q58_poi99 = new QuestionLibrary(2,"ใช่พระหรือไม่",new String[] {"ใชพระ","ไม่ใช่พระ"},new String[] {"ใชพระ"});
                           question_poi99.addQuestion(q58_poi99);
                          
                      ////

                      //set AugmentedPOI//
                      AugmentedPOI mPoi97 = new AugmentedPOI(97,11,"วัดไชยวัฒนาราม ",14.34297865994551, 100.5417251586914,"วัดไชยวัฒนาราม เป็นวัดเก่าแก่สมัยอยุธยาตอนปลายในจังหวัดพระนครศรีอยุธยา สร้างขึ้นในช่วง พ.ศ.2173 โดยพระเจ้าปราสาททอง กษัตริย์อยุธยาในสมัยนั้น โปรดให้สร้างขึ้นเพื่อเป็นอนุสรณ์แห่งชัยชนะเหนือเขมร จึงทำให้มีรูปแบบทางสถาปัตยกรรมส่วนหนึ่งมาจากปราสาทนครวัด ภายในวัดมีสิ่งที่น่าสนใจมากมาย เช่น พระปรางค์ศรีรัตนมหาธาตุ เป็นปรางค์ประธานที่ตั้งอยู่บนฐานสี่เหลี่ยมจัตุรัส แต่ละมุมของฐานมีปรางค์ประจำทิศตั้งอยู่ด้วย ซึ่งเป็นลักษณะสถาปัตยกรรมแบบสมัยอยุธยาตอนต้น นอกจากนี้ก็ยังมีจุดอื่น ๆ ที่ห้ามพลาด อาทิ ระเบียงคด, พระอุโบสถ, เมรุ, ภาพปูนปั้น, พระประธาน เป็นต้น",question_poi97);
                                AugmentedPOI mPoi99 = new AugmentedPOI(99,11,"วัดพุทไธศวรรย์ ",14.339247032034837, 100.558041036129,"วัดพุทไธศวรรย์ เป็นพระอารามหลวงที่ใหญ่โต มีชื่อเสียงและสำคัญที่สุดในรัชสมัยสมเด็จพระรามาธิบดีที่ 1 หรือ พระเจ้าอู่ทอง สร้างขึ้นในบริเวณที่ซึ่งเป็นที่ตั้งพลับพลาที่ประทับเมื่อทรงอพยพมาตั้งอยู่ก่อนสถาปนากรุงศรีอยุธยาเป็นราชธานี ปัจจุบันเป็นวัดที่มีชื่อเสียงในเรื่ององค์พ่อจตุคามรามเทพ เป็นอีกหนึ่งสิ่งศักดิ์สิทธิ์ที่นักท่องเที่ยวนิยมมาสักการะ  จุดที่น่าสนใจภายในวัด คือ ปรางค์พระประธาน มีลักษณะเป็นสถาปัตยกรรมแบบขอมสีขาวสวยงาม สิ่งที่โดดเด่นภายในวัด นอกจากนี้ยังมี มณฑป 2 หลังที่อยู่ด้านข้างของปรางค์พระประธาน, พระอุโบสถ, หมู่พระเจดีย์สิบสององค์, วิหารพระนอน, พระตำหนักสมเด็จพระพุทธโฆษาจารย์, พระนอน เป็นต้น",question_poi99);
                                 mPoiList.add(mPoi97);
                                mPoiList.add(mPoi99);
                                 
                      ////
                      }

                      public AugmentedPOI searchPosition(int mId){
                        for (AugmentedPOI objPoi : mPoiList ) {
                          if(objPoi.getPoiId()==mId){
                            return objPoi;
                          }
                        }
                        return null;
                      }

                      public MainPOI searchMainPosition(int mainId){
                        for (MainPOI objMainPoi : mMainPoiList ) {
                          if(objMainPoi.getMainPoiID()==mainId){
                            return objMainPoi;
                          }
                        }
                        return null;
                      }

                      public ArrayList getLocationList(){
                        return mPoiList;
                      }

                      public ArrayList getMainPoiList(){
                        return mMainPoiList;
                      }
                    }